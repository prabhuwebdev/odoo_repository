from . import controllers
from . import disease_prediction
from  . import patient_to_dashboard
from  . import patient_record