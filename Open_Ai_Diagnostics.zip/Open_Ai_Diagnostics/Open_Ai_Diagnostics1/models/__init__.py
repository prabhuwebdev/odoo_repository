from . import patient
from . import diagnosis